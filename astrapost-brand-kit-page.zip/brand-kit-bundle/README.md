# AstraPost brand kit page

A self-contained `/brand` route that documents your identity in one scrollable page — logo system, color tokens, typography, component samples, and downloadable assets. Drop it into any Next.js App Router project, no extra wiring.

## What's in this bundle

```
app/
└── brand/
    ├── page.tsx                    Server component, all content
    └── _components/
        └── CopyButton.tsx          Client component for click-to-copy swatches
```

## Prerequisites

This page assumes you already have:

1. **The logo components** at `@/components/brand` (`Logo.tsx`, `LogoMark.tsx`, `index.ts`) — from the earlier `astrapost-brand` bundle
2. **The color tokens** at `@/lib/tokens.ts` — from the earlier `astrapost-tokens` bundle
3. **`globals.css`** with the OKLCH variables wired up — same source as above
4. **Tailwind 4** + **shadcn/ui** conventions in the project
5. **`lucide-react`** installed (you already have it via shadcn)

If anything's missing, install in this order: brand bundle → tokens bundle → this page.

## Install

Copy the files into your project at the same paths:

```sh
# From the unzipped bundle root
cp -r app/brand <your-project>/src/app/
```

That's it. The route is now live at `http://localhost:3000/brand`.

## Path aliases

The page imports from these aliases — verify your `tsconfig.json` resolves them correctly:

```ts
import { Logo, LogoMark } from "@/components/brand";
import { neutral, brand, info, success, warning, danger, brandConstants } from "@/lib/tokens";
```

If your project uses different path aliases (e.g. `~/components/brand`), do a find-and-replace in `page.tsx` and `_components/CopyButton.tsx`.

## Asset paths

The Downloads section links to files at `/brand/*.svg`, `/app-icon-*.png`, `/og-1200x630.png`, and `/favicon.ico`. These need to exist in your `public/` directory:

```
public/
├── brand/
│   ├── lockup.svg
│   ├── lockup-black.svg
│   ├── lockup-white.svg
│   ├── lockup-rtl.svg
│   ├── mark.svg
│   ├── mark-512.png
│   ├── wordmark.svg
│   └── wordmark-arabic.svg
├── app-icon-180.png
├── app-icon-512.png
├── og-1200x630.png
└── favicon.ico
```

All of these are in the `astrapost-brand.zip` bundle delivered earlier — just unpack `svg/` into `public/brand/` and the relevant PNGs directly into `public/`.

## Privacy / SEO

The page is marked `robots: { index: false, follow: false }` in metadata — it's an internal reference page, not a public marketing surface. If you want it discoverable later, remove that line from `page.tsx`.

Want it gated behind auth? Wrap the default export in your auth boundary, or add a `middleware.ts` matcher for `/brand`. The page itself does no data fetching, so it's fast to gate either way.

## What you can edit

The page is intentionally a single file (`page.tsx`) plus one client island (`CopyButton.tsx`). Everything is co-located so you can iterate fast:

- **Add a new section?** Drop a new `<Section>` between existing ones in the default export
- **Update color descriptions?** Edit the `SCALES` array near the top of `page.tsx`
- **Add downloadable assets?** Append to the `DOWNLOADS` array
- **Change component samples?** Edit `ComponentsSection`

The shape of the data (`SCALES`, `STEP_ROLES`, `SEMANTIC_TOKENS`, `DOWNLOADS`) is hoisted to the top of the file precisely so it's easy to find and modify without diving into JSX.

## Performance notes

- The page is a **server component** — zero JS shipped to the client except the tiny `CopyButton`
- All token values come from your `@/lib/tokens.ts` at build time, no runtime fetching
- Static analysis prerenders this route automatically; no `dynamic = 'force-static'` needed
- ~1.5 KB of client JS total (just lucide icons + the copy button)

## Next steps

After dropping this in, two things you might want to add:

1. **A link to it from your dashboard** — useful for onboarding contractors or freelance designers
2. **A version stamp** — replace the `lastUpdated` date with a git-derived value or a constant you bump manually when you ship token changes
