# AstraPost brand assets

Generated logo system for AstraPost — full lockup, mark, and wordmark in three colour variants each, plus PNG raster sizes, drop-in Next.js components, and an Arabic RTL variant for `next-intl` flows.

The mark is a 4-point sparkle with concave sides — a quiet nod to "astra" (star) and the AI surface area, in the Apple-Intelligence visual family. The wordmark is Inter Medium with tight kerning. The Arabic wordmark is IBM Plex Sans Arabic Medium, chosen because it shares Inter's geometry and weight scaling more cleanly than Tajawal or Cairo.

---

## What's in the box

```
astrapost-brand/
├── svg/                                    Vector sources, font-outlined (no font dependency)
│   ├── lockup.svg                          Full lockup (currentColor)
│   ├── lockup-black.svg                    Full lockup (#0A0A0A)
│   ├── lockup-white.svg                    Full lockup (#FAFAFA)
│   ├── mark.svg                            Sparkle only (currentColor)
│   ├── mark-black.svg
│   ├── mark-white.svg
│   ├── wordmark.svg                        Wordmark only (currentColor)
│   ├── wordmark-black.svg
│   ├── wordmark-white.svg
│   ├── lockup-rtl.svg                      Arabic RTL lockup (currentColor)
│   ├── lockup-rtl-black.svg
│   ├── lockup-rtl-white.svg
│   ├── wordmark-arabic.svg                 Arabic wordmark only (currentColor)
│   ├── wordmark-arabic-black.svg
│   └── wordmark-arabic-white.svg
├── png/                                    Raster outputs
│   ├── favicon.ico                         Multi-resolution (16/32/48)
│   ├── favicon-32.png                      Modern browsers
│   ├── mark-16.png                         Browser tab fallback
│   ├── mark-32.png                         Browser tab modern
│   ├── mark-512.png                        Mark on transparent (black)
│   ├── mark-512-white.png                  Mark on transparent (white)
│   ├── app-icon-180.png                    iOS apple-touch-icon
│   ├── app-icon-192.png                    Android home screen
│   ├── app-icon-512.png                    PWA / app stores (dark icon)
│   ├── app-icon-512-light.png              PWA / app stores (light icon)
│   ├── og-1200x630.png                     Open Graph + Twitter card
│   ├── lockup-1024-light.png               Marketing reference (dark on white)
│   └── lockup-1024-dark.png                Marketing reference (white on transparent)
├── components/                             Drop-in TSX components
│   ├── Logo.tsx                            Full lockup with LTR/RTL/auto variants
│   ├── LogoMark.tsx                        Sparkle only
│   └── index.ts                            Barrel exports
└── README.md
```

All SVGs ship with text outlined to paths — they render identically regardless of which fonts are loaded on the consuming page.

---

## React components

Copy `components/` into `src/components/brand/` (or wherever your project keeps brand primitives). They're zero-dependency beyond React, fully typed, and SSR-safe.

```tsx
import { Logo, LogoMark } from "@/components/brand";

// Default LTR lockup, 28px tall
<Logo />

// Custom height + Tailwind colour
<Logo height={40} className="text-zinc-900 dark:text-zinc-50" />

// Just the mark (favicon, sidebar, X profile)
<LogoMark size={20} className="text-foreground" />

// Arabic RTL lockup
<Logo variant="rtl" />

// Auto — switches based on the nearest [dir] ancestor
// (works with next-intl when you set <html dir={locale === 'ar' ? 'rtl' : 'ltr'}>)
<Logo variant="auto" />
```

The components inherit `currentColor`, so colour theming is purely a Tailwind text-utility concern. There's no `className` plumbing for fill — set the text colour and the logo follows.

---

## Tailwind 4 integration

If you want a semantic brand-colour token rather than relying on `text-foreground`, add this to your `globals.css`:

```css
@theme {
  --color-brand: oklch(from #0A0A0A l c h);
  --color-brand-foreground: oklch(from #FAFAFA l c h);
}
```

Then `<Logo className="text-brand" />` or `<Logo className="text-brand-foreground" />`.

---

## Fonts (next/font setup)

The SVGs are font-independent, but you'll want Inter and IBM Plex Sans Arabic loaded for the rest of the UI. In `app/fonts.ts`:

```ts
import { Inter, IBM_Plex_Sans_Arabic } from "next/font/google";

export const inter = Inter({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
  variable: "--font-sans",
});

export const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["400", "500", "600"],
  display: "swap",
  variable: "--font-arabic",
});
```

Then in `app/layout.tsx`:

```tsx
import { inter, ibmPlexArabic } from "./fonts";

export default async function RootLayout({ children, params }) {
  const { locale } = await params; // next-intl
  const isRtl = locale === "ar";
  return (
    <html
      lang={locale}
      dir={isRtl ? "rtl" : "ltr"}
      className={`${inter.variable} ${ibmPlexArabic.variable}`}
    >
      <body className={isRtl ? "font-arabic" : "font-sans"}>
        {children}
      </body>
    </html>
  );
}
```

And in your Tailwind theme:

```css
@theme {
  --font-sans: var(--font-sans), ui-sans-serif, system-ui, sans-serif;
  --font-arabic: var(--font-arabic), "IBM Plex Sans Arabic", system-ui, sans-serif;
}
```

---

## Favicon setup

Drop `favicon.ico`, `favicon-32.png`, `app-icon-180.png`, `app-icon-192.png`, and `app-icon-512.png` into `public/`. Next.js 16 picks up convention-based icons automatically — but for full control, add to `app/layout.tsx`:

```tsx
export const metadata: Metadata = {
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-32.png", type: "image/png", sizes: "32x32" },
    ],
    apple: "/app-icon-180.png",
  },
  manifest: "/manifest.json",
};
```

`public/manifest.json`:

```json
{
  "name": "AstraPost",
  "short_name": "AstraPost",
  "icons": [
    { "src": "/app-icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/app-icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
  ],
  "theme_color": "#0A0A0A",
  "background_color": "#0A0A0A",
  "display": "standalone"
}
```

---

## Open Graph

`png/og-1200x630.png` is ready to drop into `public/` and reference from metadata:

```tsx
export const metadata: Metadata = {
  openGraph: {
    title: "AstraPost",
    description: "AI-powered social media management for serious creators.",
    images: [{ url: "/og-1200x630.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    images: ["/og-1200x630.png"],
  },
};
```

For per-page OG images with the lockup, use Next.js `ImageResponse` and import the lockup SVG content — but the static one is enough for marketing pages.

---

## Colour reference

The brand is intentionally monochrome. Surface colour comes from your Tailwind/Radix scale, not from the logo. These are the exact hexes used in the asset variants:

| Token            | Light value | Dark value | Usage                                    |
| ---------------- | ----------- | ---------- | ---------------------------------------- |
| `brand`          | `#0A0A0A`   | `#FAFAFA`  | Logo, primary text on neutral surfaces   |
| `brand-stroke`   | `#0A0A0A`   | `#FAFAFA`  | Hairline separator (with 0.2 opacity)    |

The hairline separator inside the lockup uses `opacity="0.2"` — that's deliberate. It's strong enough to read as a separator and faint enough that it never competes with the mark or wordmark.

---

## Arabic notes

The Arabic wordmark `أسترابوست` is the standard transliteration of "AstraPost" (the `ب` sound stands in for `P`, since Arabic has no native /p/ phoneme). Verify with a native speaker before public launch — transliterations can have a few defensible spellings, and the brand decision is yours.

The RTL lockup mirrors the layout: wordmark on the left, separator, mark on the right (so the mark anchors the visual start of the line in RTL reading order). When you set `<html dir="rtl">`, browsers won't auto-flip the SVG (it's a single element with absolute positioning inside) — `<Logo variant="auto" />` swaps between LTR and RTL builds at the component level instead.

---

## Regenerating the assets

The Python sources (`generate.py`, `render_pngs.py`) are included so you can iterate on the marks, swap fonts, or adjust kerning without losing reproducibility. You'll need:

```sh
pip install fonttools uharfbuzz cairosvg pillow brotli
```

Both font files (`Inter-Medium.ttf`, `IBMPlexSansArabic-Medium.ttf`) are in the bundle. After any tweak, run:

```sh
python generate.py && python render_pngs.py
```

If you change the wordmark text or font weight, the components in `components/` need to be regenerated too — re-run the small inline Python block at the bottom of `generate.py` or rebuild with the snippet referenced in the brand handoff.

---

## Quick acceptance checklist

Before shipping, verify the following on staging:

1. The favicon shows correctly in a browser tab against both light and dark OS themes
2. The lockup renders crisply at all the places you use it: top nav, footer, login page, marketing hero, dashboard sidebar (if applicable)
3. The mark alone is recognisable at 16×16 px (browser tab) and 56×56 px (X profile picture)
4. The Arabic lockup renders with the correct ligatures — confirm `أ`, the `س`+`ت` connection, and the `ب`+`و` in `بوست` all look right (they should — IBM Plex shapes them via OpenType, which is what HarfBuzz used during outlining)
5. The Open Graph card preview looks correct on Twitter/X, LinkedIn, and Slack unfurls
