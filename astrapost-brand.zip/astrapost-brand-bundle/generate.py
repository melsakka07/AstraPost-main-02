"""
AstraPost brand asset generator.
Outputs SVG (lockup, mark, wordmark) in 3 color variants each, plus PNG raster sizes.
Uses fontTools for glyph outlines and harfbuzz for Arabic shaping.
"""

import os
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import uharfbuzz as hb

# --- Paths ---
ROOT = "/home/claude/astrapost-brand"
INTER = os.path.join(ROOT, "Inter-Medium.ttf")
ARABIC = os.path.join(ROOT, "IBMPlexSansArabic-Medium.ttf")
SVG_DIR = os.path.join(ROOT, "svg")
PNG_DIR = os.path.join(ROOT, "png")

# --- Layout constants (pixel units in viewBox) ---
LOCKUP_HEIGHT = 90
MARK_SIZE = 56
MARK_Y_OFFSET = (LOCKUP_HEIGHT - MARK_SIZE) / 2  # 17
GAP_AFTER_MARK = 24
SEPARATOR_HEIGHT = 46
GAP_AFTER_SEPARATOR = 16
WORDMARK_FONT_SIZE = 50
WORDMARK_LETTER_SPACING_EM = -0.025  # tight kerning, Apple-style
WORDMARK_BASELINE_Y = 62

ARABIC_FONT_SIZE = 46  # Arabic typically renders larger optically; nudge down


# --- Sparkle path generator ---
def sparkle_path(size: float) -> str:
    """4-point sparkle with concave sides. Anchored at top-left of bounding box."""
    s = round(size, 2)
    h = round(s / 2, 2)
    inner = round(s * 0.4, 2)
    outer = round(s * 0.6, 2)
    return (
        f"M{h} 0 "
        f"Q{outer} {inner} {s} {h} "
        f"Q{outer} {outer} {h} {s} "
        f"Q{inner} {outer} 0 {h} "
        f"Q{inner} {inner} {h} 0 Z"
    )


# --- Glyph outlining (LTR, no shaping needed for Latin) ---
def outline_latin_text(text: str, font_path: str, font_size: float, letter_spacing_em: float = 0):
    """Returns list of glyph dicts with absolute-positioned path data and total width."""
    font = TTFont(font_path)
    glyph_set = font.getGlyphSet()
    cmap = font.getBestCmap()
    units_per_em = font["head"].unitsPerEm
    scale = font_size / units_per_em
    letter_spacing = letter_spacing_em * font_size

    glyphs = []
    x = 0.0
    for char in text:
        cp = ord(char)
        if cp not in cmap:
            x += font_size * 0.5
            continue
        glyph_name = cmap[cp]
        glyph = glyph_set[glyph_name]
        pen = SVGPathPen(glyph_set)
        glyph.draw(pen)
        d = pen.getCommands()

        if d:
            glyphs.append({
                "d": d,
                "x": x,
                "scale": scale,
            })

        advance = font["hmtx"][glyph_name][0] * scale
        x += advance + letter_spacing

    total_width = x - letter_spacing if text else 0
    return glyphs, total_width, scale


# --- Arabic outlining via HarfBuzz shaping ---
def outline_arabic_text(text: str, font_path: str, font_size: float):
    """Shape Arabic text with HarfBuzz, then get glyph outlines from fontTools.
    Returns positioned glyph paths in visual order (RTL handled by HarfBuzz)."""
    blob = hb.Blob.from_file_path(font_path)
    face = hb.Face(blob)
    font_hb = hb.Font(face)
    upem = face.upem
    font_hb.scale = (upem, upem)

    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    hb.shape(font_hb, buf)

    # Match glyph IDs to glyph names via fontTools
    ft_font = TTFont(font_path)
    glyph_order = ft_font.getGlyphOrder()
    glyph_set = ft_font.getGlyphSet()
    scale = font_size / upem

    # Total advance
    total_advance = sum(p.x_advance for p in buf.glyph_positions) * scale

    # HarfBuzz returns glyphs in visual order. For RTL, the first glyph is rightmost.
    # We'll lay them out left-to-right starting at x=0 by reversing order if RTL.
    # But HarfBuzz output for Arabic is already in display order (right-to-left for the buffer).
    # We need to compute cursor position. Standard approach: place glyphs from left,
    # accumulating advances. For RTL output buffer, the first glyph is the visually-rightmost,
    # but we lay out by accumulated advance from the start of the line.

    glyphs = []
    cursor_x = 0.0
    # For Arabic (RTL), HarfBuzz returns glyphs in visual order from start to end of line.
    # In RTL display, "start of line" is the right edge. But since we control the layout,
    # we render glyphs in buffer order from cursor_x, growing right.
    # The shaped output is already correct visually; we just position glyphs sequentially.
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        gid = info.codepoint  # post-shaping glyph ID
        gname = glyph_order[gid]
        glyph = glyph_set[gname]
        pen = SVGPathPen(glyph_set)
        glyph.draw(pen)
        d = pen.getCommands()

        if d:
            x_pos = cursor_x + pos.x_offset * scale
            y_pos = pos.y_offset * scale
            glyphs.append({
                "d": d,
                "x": x_pos,
                "y": y_pos,
                "scale": scale,
            })
        cursor_x += pos.x_advance * scale

    return glyphs, total_advance, scale


# --- SVG element builders ---
def glyph_to_path_element(glyph: dict, baseline_y: float, color: str, x_offset: float = 0, y_offset: float = 0) -> str:
    """Convert a glyph dict to an SVG <path> element with proper transform."""
    s = glyph["scale"]
    gy = glyph.get("y", 0)
    tx = glyph["x"] + x_offset
    ty = baseline_y - gy + y_offset
    transform = f"translate({tx:.3f} {ty:.3f}) scale({s:.6f} {-s:.6f})"
    return f'<path transform="{transform}" d="{glyph["d"]}" fill="{color}"/>'


def build_lockup_svg(color_fill: str, color_stroke: str = None, separator_opacity: float = 0.2):
    """Full lockup: mark + hairline + Latin wordmark."""
    if color_stroke is None:
        color_stroke = color_fill

    glyphs, wm_width, _ = outline_latin_text("AstraPost", INTER, WORDMARK_FONT_SIZE, WORDMARK_LETTER_SPACING_EM)

    sep_x = MARK_SIZE + GAP_AFTER_MARK  # 80
    text_x = sep_x + GAP_AFTER_SEPARATOR  # 96
    sep_y_top = (LOCKUP_HEIGHT - SEPARATOR_HEIGHT) / 2  # 22
    sep_y_bot = sep_y_top + SEPARATOR_HEIGHT  # 68
    total_width = text_x + wm_width

    glyph_elements = "\n    ".join(
        glyph_to_path_element(g, WORDMARK_BASELINE_Y, color_fill, x_offset=text_x) for g in glyphs
    )

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_width:.2f} {LOCKUP_HEIGHT}" fill="none" role="img" aria-label="AstraPost">
  <g transform="translate(0 {MARK_Y_OFFSET})">
    <path d="{sparkle_path(MARK_SIZE)}" fill="{color_fill}"/>
  </g>
  <line x1="{sep_x}" y1="{sep_y_top}" x2="{sep_x}" y2="{sep_y_bot}" stroke="{color_stroke}" stroke-width="1" opacity="{separator_opacity}"/>
  <g>
    {glyph_elements}
  </g>
</svg>
'''


def build_mark_svg(color_fill: str):
    """Just the sparkle, in a square viewBox."""
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {MARK_SIZE} {MARK_SIZE}" fill="none" role="img" aria-label="AstraPost">
  <path d="{sparkle_path(MARK_SIZE)}" fill="{color_fill}"/>
</svg>
'''


def build_wordmark_svg(color_fill: str):
    """Wordmark only, no mark or separator."""
    glyphs, wm_width, scale = outline_latin_text("AstraPost", INTER, WORDMARK_FONT_SIZE, WORDMARK_LETTER_SPACING_EM)
    # Use a tighter height since no mark to align with
    # Compute cap height + descender for proper viewBox
    font = TTFont(INTER)
    cap_height = font["OS/2"].sCapHeight * scale if hasattr(font["OS/2"], "sCapHeight") else WORDMARK_FONT_SIZE * 0.73
    descender = abs(font["hhea"].descent) * scale
    vb_height = cap_height + descender + 8  # small padding
    baseline = cap_height + 4

    glyph_elements = "\n  ".join(
        glyph_to_path_element(g, baseline, color_fill, x_offset=0) for g in glyphs
    )

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {wm_width:.2f} {vb_height:.2f}" fill="none" role="img" aria-label="AstraPost">
  {glyph_elements}
</svg>
'''


def build_lockup_arabic_svg(color_fill: str, color_stroke: str = None, separator_opacity: float = 0.2):
    """Arabic RTL lockup: wordmark on left of mark (since RTL reading anchors mark on the right).
    The mark sits at the visual end of the line for RTL = right side.
    Order in SVG (left-to-right): [arabic wordmark] [separator] [mark]
    """
    if color_stroke is None:
        color_stroke = color_fill

    # Arabic wordmark "أسترابوست" — transliteration of "AstraPost"
    arabic_text = "\u0623\u0633\u062a\u0631\u0627\u0628\u0648\u0633\u062a"  # أسترابوست
    glyphs, wm_width, scale = outline_arabic_text(arabic_text, ARABIC, ARABIC_FONT_SIZE)

    # Compute baseline for Arabic — IBM Plex Sans Arabic visual center is slightly different
    ft_font = TTFont(ARABIC)
    upem = ft_font["head"].unitsPerEm
    a_scale = ARABIC_FONT_SIZE / upem
    cap_h = ft_font["OS/2"].sCapHeight * a_scale if hasattr(ft_font["OS/2"], "sCapHeight") else ARABIC_FONT_SIZE * 0.7

    # Baseline position so the optical center of Arabic aligns with mark center
    # Mark center y = MARK_Y_OFFSET + MARK_SIZE/2 = 17 + 28 = 45
    arabic_baseline = MARK_Y_OFFSET + MARK_SIZE / 2 + cap_h / 2 - 2

    # Layout (left to right):
    # [wordmark] [gap] [separator] [gap] [mark]
    wm_x = 0
    sep_x = wm_width + GAP_AFTER_SEPARATOR
    mark_x = sep_x + GAP_AFTER_MARK
    sep_y_top = (LOCKUP_HEIGHT - SEPARATOR_HEIGHT) / 2
    sep_y_bot = sep_y_top + SEPARATOR_HEIGHT
    total_width = mark_x + MARK_SIZE

    glyph_elements = "\n    ".join(
        glyph_to_path_element(g, arabic_baseline, color_fill, x_offset=wm_x) for g in glyphs
    )

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_width:.2f} {LOCKUP_HEIGHT}" fill="none" role="img" aria-label="\u0623\u0633\u062a\u0631\u0627\u0628\u0648\u0633\u062a" dir="rtl">
  <g>
    {glyph_elements}
  </g>
  <line x1="{sep_x}" y1="{sep_y_top}" x2="{sep_x}" y2="{sep_y_bot}" stroke="{color_stroke}" stroke-width="1" opacity="{separator_opacity}"/>
  <g transform="translate({mark_x} {MARK_Y_OFFSET})">
    <path d="{sparkle_path(MARK_SIZE)}" fill="{color_fill}"/>
  </g>
</svg>
'''


def build_wordmark_arabic_svg(color_fill: str):
    arabic_text = "\u0623\u0633\u062a\u0631\u0627\u0628\u0648\u0633\u062a"
    glyphs, wm_width, scale = outline_arabic_text(arabic_text, ARABIC, ARABIC_FONT_SIZE)

    ft_font = TTFont(ARABIC)
    upem = ft_font["head"].unitsPerEm
    a_scale = ARABIC_FONT_SIZE / upem
    cap_h = ft_font["OS/2"].sCapHeight * a_scale if hasattr(ft_font["OS/2"], "sCapHeight") else ARABIC_FONT_SIZE * 0.7
    descender = abs(ft_font["hhea"].descent) * a_scale
    # Arabic has marks above the baseline (ascender region) — we need top room too
    ascender = ft_font["hhea"].ascent * a_scale
    vb_height = ascender + descender * 0.8 + 4
    baseline = ascender + 2

    glyph_elements = "\n  ".join(
        glyph_to_path_element(g, baseline, color_fill, x_offset=0) for g in glyphs
    )

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {wm_width:.2f} {vb_height:.2f}" fill="none" role="img" aria-label="\u0623\u0633\u062a\u0631\u0627\u0628\u0648\u0633\u062a" dir="rtl">
  {glyph_elements}
</svg>
'''


# --- Generation ---
def write(path, content):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"  wrote {os.path.relpath(path, ROOT)} ({len(content)} chars)")


def main():
    print("Generating SVGs…")

    # Color variants
    variants = [
        ("currentColor", "currentColor", "lockup.svg", "mark.svg", "wordmark.svg", "lockup-rtl.svg", "wordmark-arabic.svg"),
        ("#0A0A0A", "#0A0A0A", "lockup-black.svg", "mark-black.svg", "wordmark-black.svg", "lockup-rtl-black.svg", "wordmark-arabic-black.svg"),
        ("#FAFAFA", "#FAFAFA", "lockup-white.svg", "mark-white.svg", "wordmark-white.svg", "lockup-rtl-white.svg", "wordmark-arabic-white.svg"),
    ]

    for color, stroke, lockup, mark, wm, rtl, wm_ar in variants:
        write(os.path.join(SVG_DIR, lockup), build_lockup_svg(color, stroke))
        write(os.path.join(SVG_DIR, mark), build_mark_svg(color))
        write(os.path.join(SVG_DIR, wm), build_wordmark_svg(color))
        write(os.path.join(SVG_DIR, rtl), build_lockup_arabic_svg(color, stroke))
        write(os.path.join(SVG_DIR, wm_ar), build_wordmark_arabic_svg(color))

    print("Done with SVGs.")


if __name__ == "__main__":
    main()
