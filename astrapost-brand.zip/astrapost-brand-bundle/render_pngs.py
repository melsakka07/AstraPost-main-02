"""Render PNG variants from the SVG sources."""
import os
import cairosvg
from PIL import Image, ImageDraw

ROOT = "/home/claude/astrapost-brand"
SVG_DIR = os.path.join(ROOT, "svg")
PNG_DIR = os.path.join(ROOT, "png")


def render_svg_to_png(svg_path: str, out_path: str, size: int, transparent: bool = True):
    """Render an SVG to PNG at given size (width)."""
    kwargs = {"url": svg_path, "write_to": out_path, "output_width": size}
    if not transparent:
        kwargs["background_color"] = "white"
    cairosvg.svg2png(**kwargs)
    print(f"  wrote {os.path.relpath(out_path, ROOT)}")


def make_app_icon(out_path: str, size: int, bg_color: tuple, sparkle_color: str, corner_radius_pct: float = 0.225):
    """Compose an iOS-style app icon: rounded square bg with centered sparkle."""
    icon = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(icon)
    radius = int(size * corner_radius_pct)
    draw.rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill=bg_color)

    # Render sparkle SVG to a temp PNG then paste centered
    sparkle_svg = os.path.join(SVG_DIR, f"mark-{sparkle_color}.svg")
    sparkle_size = int(size * 0.5)  # sparkle takes 50% of icon area
    tmp = "/tmp/_sparkle_for_icon.png"
    cairosvg.svg2png(url=sparkle_svg, write_to=tmp, output_width=sparkle_size)

    sparkle = Image.open(tmp).convert("RGBA")
    offset = ((size - sparkle.width) // 2, (size - sparkle.height) // 2)
    icon.paste(sparkle, offset, sparkle)
    icon.save(out_path, "PNG")
    print(f"  wrote {os.path.relpath(out_path, ROOT)}")


def make_og_image(out_path: str, width: int = 1200, height: int = 630, bg_color: tuple = (10, 10, 10)):
    """Open Graph image: lockup centered on dark background."""
    canvas = Image.new("RGBA", (width, height), bg_color + (255,))

    # Render the white lockup at appropriate size
    lockup_width = int(width * 0.5)  # lockup takes 50% of canvas width
    tmp = "/tmp/_lockup_og.png"
    cairosvg.svg2png(url=os.path.join(SVG_DIR, "lockup-white.svg"), write_to=tmp, output_width=lockup_width)
    lockup = Image.open(tmp).convert("RGBA")
    offset = ((width - lockup.width) // 2, (height - lockup.height) // 2)
    canvas.paste(lockup, offset, lockup)
    canvas.save(out_path, "PNG")
    print(f"  wrote {os.path.relpath(out_path, ROOT)}")


def main():
    print("Rendering PNGs…")

    # Mark PNGs (transparent background, black sparkle)
    render_svg_to_png(os.path.join(SVG_DIR, "mark-black.svg"), os.path.join(PNG_DIR, "mark-512.png"), 512)
    render_svg_to_png(os.path.join(SVG_DIR, "mark-black.svg"), os.path.join(PNG_DIR, "mark-32.png"), 32)
    render_svg_to_png(os.path.join(SVG_DIR, "mark-black.svg"), os.path.join(PNG_DIR, "mark-16.png"), 16)

    # White mark for use on dark backgrounds
    render_svg_to_png(os.path.join(SVG_DIR, "mark-white.svg"), os.path.join(PNG_DIR, "mark-512-white.png"), 512)

    # App icons (rounded-square bg with sparkle inside)
    make_app_icon(os.path.join(PNG_DIR, "app-icon-512.png"), 512, bg_color=(10, 10, 10, 255), sparkle_color="white")
    make_app_icon(os.path.join(PNG_DIR, "app-icon-180.png"), 180, bg_color=(10, 10, 10, 255), sparkle_color="white")
    make_app_icon(os.path.join(PNG_DIR, "app-icon-192.png"), 192, bg_color=(10, 10, 10, 255), sparkle_color="white")
    make_app_icon(os.path.join(PNG_DIR, "app-icon-512-light.png"), 512, bg_color=(255, 255, 255, 255), sparkle_color="black")

    # OG image (1200x630 dark with white lockup)
    make_og_image(os.path.join(PNG_DIR, "og-1200x630.png"))

    # Lockup PNG renders for asset reference (PR cards, README hero, etc.)
    render_svg_to_png(os.path.join(SVG_DIR, "lockup-black.svg"), os.path.join(PNG_DIR, "lockup-1024-light.png"), 1024, transparent=False)
    render_svg_to_png(os.path.join(SVG_DIR, "lockup-white.svg"), os.path.join(PNG_DIR, "lockup-1024-dark.png"), 1024, transparent=True)

    print("Done with PNGs.")


if __name__ == "__main__":
    main()
